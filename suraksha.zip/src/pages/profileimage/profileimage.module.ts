import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ProfileimagePage } from './profileimage';

@NgModule({
  declarations: [
    ProfileimagePage,
  ],
  imports: [
    IonicPageModule.forChild(ProfileimagePage),
  ],
})
export class ProfileimagePageModule {}
