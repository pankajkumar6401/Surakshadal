import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FamilydetailPage } from './familydetail';

@NgModule({
  declarations: [
    FamilydetailPage,
  ],
  imports: [
    IonicPageModule.forChild(FamilydetailPage),
  ],
})
export class FamilydetailPageModule {}
